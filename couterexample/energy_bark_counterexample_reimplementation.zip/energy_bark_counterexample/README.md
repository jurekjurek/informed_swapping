# Explicit sparse counterexample: incremental energy-BARK vs SKQD

This is a standalone implementation of the energy-BARK scoring and remembered-frontier rule described in the paper's Section II B–C; it does not import or modify the user's repository.

Run from this directory:

```bash
python -m pip install numpy scipy matplotlib
python energy_bark_counterexample.py --m 6 --shots 200
```

Output: `results/fidelity_vs_subspace.png`, `results/exponential_delay.png`, and CSV tables.

## Hamiltonian

Vertices consist of cube states `z in {0,1}^m` (seed `s=0^m`) and special states `a,y,d,c`.

- On the cube: `H[z,z] = U*popcount(z)`, and `H[z,z xor e_i] = -1`.
- `H[s,a]=-2`, `H[a,e_i]=-1` for each single-flip cube vertex `e_i`.
- `H[s,y]=+1.8`, `H[a,y]=-1.8`.
- `H[y,d]=H[d,c]=-1`, `H[c,c]=-2.2`.
- All unspecified matrix entries vanish. Set `U=20*m*m`.

The active matrix is `2**m+4` dimensional. It can be embedded into an `(m+1)`-qubit computational basis with unused basis states assigned high uncoupled energies. This is a **sparse, efficiently describable, but non-k-local in general** Hamiltonian; it is not a conventional nearest-neighbor Ising model.

The exact ground state is confined to the invariant target sector spanned by `(|s>-|a>)/sqrt(2), y,d,c`, and has exactly five nonzero computational-basis coefficients. The overlap of the seed with the ground state is approximately 0.014729, and the gap is bounded below by a positive constant for `m >= 2`.

After choosing `a`, energy-BARK's approximate reference has equal coefficients on `s,a`, so the coupling to the gateway `y` cancels. Every other undiscovered cube state is reachable through a nonzero attractive edge, and offers some energy improvement. Therefore energy-BARK exhausts all `2**m` cube states before choosing `y`; it then adds `d,c`. This happens even if the projected eigenvector is recomputed exactly after every step, since the selected cube subspace preserves the exchange symmetry `s <-> a`.

For SKQD, the seed contains a nonzero antisymmetric component, so it evolves into the `y,d,c` sector. At `t=1.5`, each of the five ground-state-supported bitstrings has a constant measurement probability (about 0.044 or greater for the values tested), independent of the total cube size asymptotically.

The plot compares **subspace fidelity**, not wall-time quantum advantage. SKQD uses a chosen evolution time and a finite sampling budget.
